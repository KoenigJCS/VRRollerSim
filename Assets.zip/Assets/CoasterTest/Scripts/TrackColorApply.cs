//CS484
//Vladislav Petrov

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Dreamteck.Splines;

public class TrackColorApply : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        foreach(SplineMesh trackMesh in GetComponentsInChildren<SplineMesh>())
        {
            trackMesh.GetComponent<Renderer>().material.color = new Color(Random.value, Random.value, Random.value, 1.0f);
        }
    }
}
