//CS484
//Vladislav Petrov

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Dreamteck.Splines;

public class CartMovement : MonoBehaviour
{
    public float pitch = 0.0f;
    public float speed = 0.0f;
    public float acceleration = 0.0f;
    public SplineFollower trackFollower;
    public AudioSource movementSound;
    public AudioSource chainSound;
    public List<GameObject> train;
    public GameObject mainCart;
    public List<Camera> CartCams;
    public int cameraIndex = 0;
    public bool freeTrack = true;
    public bool liftTrack = false;
    public bool stationTrack = false;

    public Color cartColor;


    // Start is called before the first frame update
    void Start()
    {
        cartColor = new Color(Random.value, Random.value, Random.value, 1.0f);

        foreach (GameObject cart in train)
        {
            //Assign cameras
            CartCams.Add(cart.GetComponentInChildren<Camera>(true));

            foreach(Renderer renderer in cart.GetComponentsInChildren<Renderer>())
            {
                if(renderer.gameObject.name == "Body")
                {
                    renderer.material.color = cartColor;
                }
            }
        }

        //Find the middle cart. This is for better physics.
        mainCart = train[train.Count / 2];
    }

    // Update is called once per frame
    void Update()
    {
        //Select cart camera with arrow keys
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            CartCams[cameraIndex].enabled = false;
            CartCams[cameraIndex].GetComponent<AudioListener>().enabled = false;
            if (cameraIndex < CartCams.Count - 1)
            {
                cameraIndex++;
            }
            CartCams[cameraIndex].enabled = true;
            CartCams[cameraIndex].GetComponent<AudioListener>().enabled = true;
        }
        else if(Input.GetKeyDown(KeyCode.LeftArrow))
        {
            CartCams[cameraIndex].enabled = false;
            CartCams[cameraIndex].GetComponent<AudioListener>().enabled = false;
            if (cameraIndex > 0)
            {
                cameraIndex--;
            }
            CartCams[cameraIndex].enabled = true;
            CartCams[cameraIndex].GetComponent<AudioListener>().enabled = true;
        }


        //Figure out the acceleration and speed based on the angle when on free track
        if(freeTrack)
        {
            //Pitch Down
            if(mainCart.transform.localEulerAngles.x < 180)
            {
                pitch = mainCart.transform.localEulerAngles.x / 5000;
            }
            //Pitch Up
            else
            {
                pitch = (mainCart.transform.localEulerAngles.x - 360) / 5000;
            }
            acceleration = pitch;
            speed += acceleration;
        }

        //Lift hill
        if(liftTrack)
        {
            if(speed < 2)
            {
                speed += 0.025f;
            }
            if(speed > 2)
            {
                speed -= 0.025f;
            }
            acceleration = 0;
        }

        //Apply same speed and direction to all carts in the train.
        foreach (GameObject cart in train)
        {
            trackFollower = cart.GetComponent<SplineFollower>();
            if (speed >= 0)
            {
                trackFollower.direction = Spline.Direction.Forward;
            }
            else
            {
                trackFollower.direction = Spline.Direction.Backward;
            }
            trackFollower.followSpeed = speed;
        }

        //Sound effetcs
        movementSound.pitch = Mathf.Abs(speed) / 10;
        chainSound.pitch = Mathf.Abs(speed) / 2;
    }


    //Triggers
    void freeTrackFunction()
    {
        freeTrack = true;
        liftTrack = false;
        stationTrack = false;
        chainSound.Stop();
    }

    void liftTrackFunction()
    {
        freeTrack = false;
        liftTrack = true;
        stationTrack = false;
        chainSound.Play();
    }

    void stationTrackFunction()
    {

    }
}


